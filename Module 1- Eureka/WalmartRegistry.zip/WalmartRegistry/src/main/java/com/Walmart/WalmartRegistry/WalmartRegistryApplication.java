package com.Walmart.WalmartRegistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalmartRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalmartRegistryApplication.class, args);
	}

}
