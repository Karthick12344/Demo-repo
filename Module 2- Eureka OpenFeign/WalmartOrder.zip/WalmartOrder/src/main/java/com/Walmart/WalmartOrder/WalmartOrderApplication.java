package com.Walmart.WalmartOrder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalmartOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalmartOrderApplication.class, args);
	}

}
