package com.Walmart.WalmartPayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalmartPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalmartPaymentApplication.class, args);
	}

}
